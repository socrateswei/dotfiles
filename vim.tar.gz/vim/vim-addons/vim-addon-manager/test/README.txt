How to run?
See doc/vim-addon-manager-additional-documentation.txt, Section 9
